using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explode : MonoBehaviour
{
    [SerializeField] float RaioExplosao = 10.0f;
    [SerializeField] float ForcaExplosao = 100.0f;
    [SerializeField] int TiraVida = 50;
    [SerializeField] bool TemTimer = false; //com timer só explode no fim do TempoExplodir
    [SerializeField] float TempoExplodir = 1f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (TemTimer==true)
        {
            TempoExplodir = TempoExplodir - Time.deltaTime;
            if(TempoExplodir < 0)
            {
                Explodir();
            }
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(TemTimer==false)
        {
            Explodir();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (TemTimer == false)
        {
            Explodir();
        }
    }
    public void Explodir()
    {
        Vector3 posicaoExplosao = transform.position;
        Collider[] colliders = Physics.OverlapSphere(posicaoExplosao, RaioExplosao);
        foreach(Collider obj in colliders)
        {
            //para evitar que o player perca vida duas vezes
            //ignorando o CharacterController
            if (obj is CharacterController) continue;

            Rigidbody rb=obj.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(ForcaExplosao, posicaoExplosao, RaioExplosao, 3.0f);
            }

            Vida vd = obj.GetComponent<Vida>();
            if(vd!=null)
            {
                vd.PerdeVida(TiraVida);
            }
        }
        //TODO: Som e efeitos de particulas
        Destroy(this.gameObject);
    }
}
