using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Script para as armadilhas
/// </summary>
public class TiraVida : MonoBehaviour
{
    public int ValorTirarVida=10;
    public  float IntervaloPerderVida = 3;
    float _proximoIntervalo = 0;

    void ProcessaColisao(GameObject gameObject)
    {
        if (Time.time<_proximoIntervalo) return;
        var vida=gameObject.GetComponent<Vida>();
        if (vida!=null){
            vida.PerdeVida(ValorTirarVida);
            _proximoIntervalo = Time.time + IntervaloPerderVida;
        }
    }

    private void OnCollisionEnter(Collision other) {
        ProcessaColisao(other.gameObject);
    }
    private void OnTriggerEnter(Collider other) {
        ProcessaColisao(other.gameObject);
    }
    private void OnCollisionStay(Collision other) {
        ProcessaColisao(other.gameObject);
    }
    private void OnTriggerStay(Collider other) {
        ProcessaColisao(other.gameObject);
    }
}
