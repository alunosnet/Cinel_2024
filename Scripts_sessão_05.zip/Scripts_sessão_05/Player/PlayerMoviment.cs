using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerMoviment : MonoBehaviour
{
    CharacterController _cc;
    [SerializeField] float VelocidadeMovimento=2;
    [SerializeField] float VelocidadeRotacao=5;
    [SerializeField] float VelocidadeSalto = -2;
    Vector3 _velocidade;
    [SerializeField] bool _isGrounded;
    public float _movimentoInput =0;
    public bool Saltou=false;
    // Start is called before the first frame update
    void Start()
    {
        _cc=GetComponent<CharacterController>();
        if (_cc==null)
            Debug.Log("Falta o CharacterController",this);
    }
    
    // Update is called once per frame
    void Update()
    {
        //rotação
        float _rotacaoInput = Input.GetAxisRaw("Horizontal");
        transform.Rotate(0, _rotacaoInput * Time.deltaTime * VelocidadeRotacao, 0);
        //movimento
        _movimentoInput = Input.GetAxisRaw("Vertical");

        //correr
        if (_movimentoInput > 0){
            if (Input.GetButton("Run"))
                _movimentoInput *= 2;
        }
        
        Vector3 movimento = transform.forward * _movimentoInput * Time.deltaTime * VelocidadeMovimento;
        if (_movimentoInput<0)
            movimento *=0.2f;
        _cc.Move(movimento);
        //salto
        if (Input.GetButton("Jump") && _isGrounded)
        {
            _velocidade.y = Mathf.Sqrt(VelocidadeSalto * Physics.gravity.y);
            Saltou = true;
        }
        //gravidade
        _velocidade += Physics.gravity * Time.deltaTime;
        _cc.Move(_velocidade * Time.deltaTime);
        _isGrounded = _cc.isGrounded;
    }
    
}
