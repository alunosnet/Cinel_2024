using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnim : MonoBehaviour
{
    Animator _animator;
    PlayerMoviment _playerMoviment;
    Atirar _atirar;
    // Start is called before the first frame update
    void Start()
    {
        _animator=GetComponentInChildren<Animator>();
        _playerMoviment=GetComponent<PlayerMoviment>();
        _atirar=GetComponentInChildren<Atirar>();
    }

    // Update is called once per frame
    void Update()
    {
        //Animações do movimento
        _animator.SetFloat("velocidade", _playerMoviment._movimentoInput);

        if (_playerMoviment.Saltou)
        {
            _animator.SetTrigger("saltou");
            _playerMoviment.Saltou=false;
        }

        if (_atirar.Atirou)
        {
            _animator.SetTrigger("atirou");
            _atirar.Atirou=false;
        }
    }
}
