using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Atirar : MonoBehaviour
{
    [SerializeField] GameObject Objeto;
    [SerializeField] Transform PontoAtirar;
    [SerializeField] float ForcaAtirar = 100;
    [SerializeField] float IntervaloAtirar = 0.5f;
    float NovoIntervalo = 0;

    public bool Atirou;
    // Start is called before the first frame update
    void Start()
    {
      
    }

    void FixedUpdate()
    {
        if (Input.GetButtonDown("Fire1"))
        {

            if (Time.time < NovoIntervalo) 
                return;
            Atirou=true;
        }
    }

    public void AtirarObjeto()
    {
    
        
        var obj=Instantiate(Objeto,PontoAtirar.position,Quaternion.identity);

        obj.GetComponent<Rigidbody>().AddForce(transform.forward * ForcaAtirar);

        Destroy(obj,5);

        NovoIntervalo = Time.time + IntervaloAtirar;
    }
}
