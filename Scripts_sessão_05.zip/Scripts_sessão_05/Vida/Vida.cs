using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vida : MonoBehaviour
{
    public int MaxVida = 100;
    public int VidaAtual;
    // Start is called before the first frame update
    void Start()
    {
        VidaAtual=MaxVida;
    }
    public void PerdeVida(int valor)
    {
        VidaAtual = VidaAtual - valor;
        if (VidaAtual<0)
        {
            VidaAtual = 0;
            Debug.Log("Morreu " + transform.name);
        }
    }
    public void GanhaVida(int valor)
    {
        VidaAtual = VidaAtual + valor;
        if (VidaAtual>MaxVida)
        {
            VidaAtual = MaxVida;
        }
    }
    public bool Morreu()
    {
        if (VidaAtual==0) return true;
        return false;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
